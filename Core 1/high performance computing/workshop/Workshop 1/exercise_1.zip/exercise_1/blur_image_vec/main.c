// HPC workshop - University of Durham 
// author: Alejandro Benitez-Llambay
// data: November 2018
// purpose: demonstrate the advantages of using OpenMP for image processing

#include <stdlib.h>
#include <stdio.h>
#include "proto.h"
#include <time.h>

void
main (int argc, char *argv[])
{
  struct Image myimage;
  int n_threads;
  double cpu_time;
  clock_t start, end;
  struct Image output;

  read_ppm (argv[1], &myimage);

  int n = 10;

  output = blur_mean (myimage, n);

  write_ppm (argv[2], output);
}
