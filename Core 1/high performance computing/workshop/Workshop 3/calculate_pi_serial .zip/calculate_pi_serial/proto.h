
// This file is part of the HPC workshop 2019 at Durham University 
// Author: Christian Arnold


double calculate_pi(int N);
