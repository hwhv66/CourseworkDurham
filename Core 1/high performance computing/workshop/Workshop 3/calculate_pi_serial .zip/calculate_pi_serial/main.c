
// This file is part of the HPC workshop 2019 at Durham University 
// Author: Christian Arnold

/* 
 * This program calculates the numerical value of the constant PI. 
 */

#include <stdlib.h>
#include <stdio.h>
#include "proto.h"
#include <time.h>
#include <math.h>
#define M_PI 3.141592653589793
/*
 * The program takes one argument: the name of the file containing the 
 * numbers in binary format.
 */
int main(int argc, char *argv[])
{
  clock_t start, end;

  int N; /* the total count of random coordinates vectors */
  N = atoi(argv[1]);

  start = clock();
  
  double my_pi = calculate_pi(N);

  end = clock();

  double time = ((double) end - start) / CLOCKS_PER_SEC;

  double error = M_PI - my_pi;
  printf("The value of Pi is %.20f, the error is  %.20f\n", my_pi, error);
  printf("The calculatetion took %g s\n", time);
  
  return 0;
}
